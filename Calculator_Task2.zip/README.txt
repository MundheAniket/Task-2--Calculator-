
# Simple Calculator

## Description
This is a basic calculator program written in Python. It performs the following arithmetic operations:
- Addition
- Subtraction
- Multiplication
- Division

## How to Run
1. Ensure you have Python installed.
2. Run the script using the command: `python calculator.py`
3. Follow the prompts to enter two numbers and choose an operation.
4. The result will be displayed.

## Author
Sunil Kotkar
